import random

import pygame

import player
from config_file.config_game import *
from player import Player
from enemy import *
from sprites import Character


class World:
    def __init__(self):
        self.surface = pygame.display.get_surface()
        self.all_sprites = Camera()
        self.setup()

    def setup(self):
        Character((0, 0), pygame.image.load("data/images/background.jpg"), self.all_sprites, 3)
        self.player = Player((self.surface.get_size()[0] // 2, self.surface.get_size()[1] // 2), self.all_sprites)

    def create(self, t):
        self.surface.fill("black")
        self.all_sprites.drawing(self.player)
        self.all_sprites.update(t)


class Camera(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.surface = pygame.display.get_surface()
        self.offset = pygame.math.Vector2()


    def drawing(self, player):
        self.offset.x = player.rect.centerx - SCREEN_WIDTH / 2
        self.offset.y = player.rect.centery - SCREEN_HEIGHT / 2
        for layer in LAYERS:
            for sprite in self.sprites():
                if sprite.z == layer:
                    offset_rect = sprite.rect.copy()
                    offset_rect.center -= self.offset
                    self.surface.blit(sprite.image, offset_rect)


