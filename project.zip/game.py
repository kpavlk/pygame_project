import sys

from def_and_class import Keyboard, generate

import pygame
from config_file.config_game import *
from world import World
import sqlite3


class Game:
    def __init__(self):
        pygame.init()
        self.con = sqlite3.connect('data/game.sqlite3')
        self.cur = self.con.cursor()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
        # Задаём параметры экрана
        self.clock = pygame.time.Clock()
        self.enemy_sprites = pygame.sprite.Group()
        pygame.display.set_caption("Game")
        self.state = "menu"
        # Устанавливаем текущее состояние для показа нужной сцены
        self.world = World()

    def draw_start_menu(self):
        self.screen.fill((0, 0, 0))
        font = pygame.font.SysFont('arial', 40)
        title = font.render('Игра', True, (255, 255, 255))
        start_button = font.render('Начать - [пробел]', True, (255, 255, 255))
        self.screen.blit(title, (SCREEN_WIDTH / 2 - title.get_width() / 2, SCREEN_HEIGHT / 2 - title.get_height() / 2))
        self.screen.blit(start_button, (
        SCREEN_WIDTH / 2 - start_button.get_width() / 2, SCREEN_HEIGHT / 2 + start_button.get_height() / 2))
        pygame.display.update()

    def x(q):
        global activ, act_word
        activ = True
        act_word = q


    def start_game(self):
        keyboard = Keyboard()
        data = []
        activ = True
        act_word = ""
        self.enemy_sprites.add(generate(3, 3, 3))
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    self.con.commit()
                    self.con.close()
                    pygame.quit()
                    sys.exit()
            # Изменение времени в цикле
            t = self.clock.tick() / 1000
            # Переключение сцен
            if self.state == "menu":
                self.draw_start_menu()
                keys = pygame.key.get_pressed()
                if keys[pygame.K_SPACE]:
                    self.state = "game"
                    game_over = False
            if self.state == "game":
                # Создание мира, отрисовка спрайтов и карты
                self.world.create(t)
                if pygame.mouse.get_focused():
                    self.enemy_sprites.update((SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), act_word)
                if activ:
                    activ = False
                    self.enemy_sprites.update(pygame.mouse.get_pos(), act_word)
                    act_word = ""
                    data = []
                    for i in self.enemy_sprites.sprites():
                        data.append((i.name, i.distance, self.x))
                    keyboard.set_active_words(data)
                self.enemy_sprites.draw(self.screen)
            pygame.display.flip()
            pygame.display.update()