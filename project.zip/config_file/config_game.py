from pygame import *
init()

SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080
ARIAL_50 = font.SysFont('Arial', 50)
LAYERS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
word_s = ['Кот', 'Дом', 'Печь']
word_m = ['Резонный', 'Подсадить', 'Самосвал']
word_l = ['термоядерная физика', 'Церковноприходский', 'Фехтовальщик']
size = width, height = 1920, 1080